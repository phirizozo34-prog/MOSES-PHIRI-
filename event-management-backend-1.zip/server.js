// server.js
const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const { WebSocketServer } = require("ws");

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "your-super-secret-key";

app.use(cors({
  origin: ["http://localhost:5500", "https://your-frontend-domain.com"],
  credentials: true,
}));
app.use(express.json());

// --- Simple In-Memory Database (for testing) ---
const users = [];
const events = [];

// --- Authentication Routes ---
app.post("/auth/signup", (req, res) => {
  const { email, password, role } = req.body;
  if (users.find((u) => u.email === email)) {
    return res.status(400).json({ message: "User already exists" });
  }
  const hashed = bcrypt.hashSync(password, 10);
  const newUser = { email, password: hashed, role };
  users.push(newUser);
  res.json({ message: "Signup successful" });
});

app.post("/auth/login", (req, res) => {
  const { email, password } = req.body;
  const user = users.find((u) => u.email === email);
  if (!user || !bcrypt.compareSync(password, user.password)) {
    return res.status(401).json({ message: "Invalid credentials" });
  }
  const token = jwt.sign({ email: user.email, role: user.role }, JWT_SECRET, { expiresIn: "2h" });
  res.json({ token });
});

// --- Event Routes ---
app.get("/events", (req, res) => res.json(events));

app.post("/events", (req, res) => {
  const { title, date } = req.body;
  const newEvent = { id: events.length + 1, title, date };
  events.push(newEvent);

  // Broadcast to all WebSocket clients
  broadcast({ type: "new_event", data: newEvent });
  res.json({ message: "Event created", event: newEvent });
});

// --- Basic Route ---
app.get("/", (req, res) => {
  res.send("✅ Event Management Backend is running!");
});

// --- Start HTTP Server ---
const server = app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});

// --- WebSocket Setup ---
const wss = new WebSocketServer({ server });

function broadcast(message) {
  wss.clients.forEach((client) => {
    if (client.readyState === 1) {
      client.send(JSON.stringify(message));
    }
  });
}

wss.on("connection", (ws) => {
  console.log("🔌 New WebSocket connection");
  ws.send(JSON.stringify({ type: "welcome", message: "Connected to WebSocket server!" }));
});
