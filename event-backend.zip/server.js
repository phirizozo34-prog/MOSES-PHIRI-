// ================================
// EVENT MANAGEMENT BACKEND SERVER
// ================================

const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const WebSocket = require("ws");
const { randomUUID } = require("crypto");

const app = express();
const PORT = process.env.PORT || 5000;
const SECRET_KEY = "event_secret_key";

// Middleware
app.use(cors());
app.use(express.json());

// In-memory database
const db = {
  users: [],
  events: [],
  rsvps: []
};

const generateId = () => randomUUID();

// ========== AUTH ==========
app.post("/register", async (req, res) => {
  const { username, password, role = "USER" } = req.body;
  if (db.users.find(u => u.username === username)) {
    return res.status(400).json({ error: "User already exists" });
  }

  const hashed = await bcrypt.hash(password, 10);
  const user = { id: generateId(), username, password: hashed, role };
  db.users.push(user);

  res.json({ message: "User registered", user: { id: user.id, username, role } });
});

app.post("/login", async (req, res) => {
  const { username, password } = req.body;
  const user = db.users.find(u => u.username === username);
  if (!user) return res.status(404).json({ error: "User not found" });

  const valid = await bcrypt.compare(password, user.password);
  if (!valid) return res.status(401).json({ error: "Invalid credentials" });

  const token = jwt.sign({ id: user.id, username, role: user.role }, SECRET_KEY, { expiresIn: "2h" });
  res.json({ message: "Login successful", token });
});

function authenticate(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ error: "Missing token" });

  const token = auth.split(" ")[1];
  jwt.verify(token, SECRET_KEY, (err, user) => {
    if (err) return res.status(403).json({ error: "Invalid token" });
    req.user = user;
    next();
  });
}

// ========== EVENTS ==========
app.post("/events", authenticate, (req, res) => {
  const { name, date } = req.body;
  const event = {
    id: generateId(),
    name,
    date,
    organizerId: req.user.id,
    approved: req.user.role === "ADMIN",
    createdAt: new Date().toISOString()
  };
  db.events.push(event);
  broadcast({ type: "EVENT_CREATED", data: event });
  res.json({ message: "Event created", event });
});

app.get("/events", (req, res) => {
  res.json(db.events);
});

app.delete("/events/:id", authenticate, (req, res) => {
  const eventIndex = db.events.findIndex(e => e.id === req.params.id);
  if (eventIndex === -1) return res.status(404).json({ error: "Event not found" });

  const event = db.events[eventIndex];
  if (req.user.role !== "ADMIN" && event.organizerId !== req.user.id) {
    return res.status(403).json({ error: "Not authorized to delete this event" });
  }

  db.events.splice(eventIndex, 1);
  db.rsvps = db.rsvps.filter(r => r.eventId !== req.params.id);
  broadcast({ type: "EVENT_DELETED", data: { id: req.params.id } });
  res.json({ message: "Event deleted" });
});

app.post("/events/:id/rsvp", authenticate, (req, res) => {
  const { status } = req.body;
  if (!["GOING", "MAYBE", "NOT_GOING"].includes(status)) {
    return res.status(400).json({ error: "Invalid RSVP status" });
  }

  const event = db.events.find(e => e.id === req.params.id);
  if (!event) return res.status(404).json({ error: "Event not found" });
  if (!event.approved) return res.status(400).json({ error: "Cannot RSVP to unapproved event" });

  let rsvp = db.rsvps.find(r => r.eventId === req.params.id && r.userId === req.user.id);
  if (rsvp) {
    rsvp.status = status;
    rsvp.updatedAt = new Date().toISOString();
  } else {
    rsvp = { id: generateId(), eventId: req.params.id, userId: req.user.id, status, createdAt: new Date().toISOString() };
    db.rsvps.push(rsvp);
  }

  broadcast({ type: rsvp.updatedAt ? "RSVP_UPDATED" : "RSVP_CREATED", data: rsvp });
  res.json({ message: "RSVP recorded", rsvp });
});

const server = app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});

const wss = new WebSocket.Server({ server });

wss.on("connection", (ws) => {
  console.log("New WebSocket connection");
  ws.on("close", () => console.log("WebSocket connection closed"));
  ws.on("error", (err) => console.error("WebSocket error:", err));
});

function broadcast(message) {
  const data = JSON.stringify(message);
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) client.send(data);
  });
}

process.on("SIGTERM", () => {
  console.log("SIGTERM received, closing server...");
  server.close(() => {
    console.log("Server closed");
    process.exit(0);
  });
});
